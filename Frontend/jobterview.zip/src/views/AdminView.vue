<template>
    <h3 class="text-center mt-3">Admin</h3>
    <router-view/>
</template>

<script>
export default {
    name: "AdminView",
    components: {

    },
    setup() {

    },
}
</script>

<style scoped>

</style>