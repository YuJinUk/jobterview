<template>
    <router-view/>
</template>

<script>
export default {
    name: 'AuthView',
}
</script>