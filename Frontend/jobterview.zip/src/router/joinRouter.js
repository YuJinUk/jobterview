const joinRouter=[
    {
    path:'/member/Join',
    name: 'Join',
    component : () => import('@/views/components/Join.vue')
    },
]

export default joinRouter;
